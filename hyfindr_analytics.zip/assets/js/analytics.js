const customizeRangeButton = document.querySelector('#customizeRange');
const customizeRangeForm = document.querySelector('#customizeRangeForm');
customizeRangeButton.addEventListener('click', function (e) {
  const thisButton = e.target;
  console.log(thisButton);
  let isEnabled = customizeRangeForm.classList.contains('hidden');
  if (!isEnabled) { 
    customizeRangeForm.classList.add('hidden');
    thisButton.classList.remove('red');
  } else {
    customizeRangeForm.classList.remove('hidden');
    thisButton.classList.add('red');
  }
});

// Total Votes
const totalVotes = document.getElementById('totalVotes');
new Chart(totalVotes, {
  type: 'bar',
  data: {
    // labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [{
      label: ['# of Votes'],
      data: [12, 19, 3, 5, 2, 3, 12, 19, 3, 5, 2, 3],
      borderWidth: 1
    }]
  },
  options: {
    scales: {
      y: {
        beginAtZero: true
      }
    }
  }
});

// Total Products
const storeProducts = document.getElementById('storeProducts');
const categoryProducts = document.getElementById('categoryProducts');

new Chart(storeProducts, {
  type: 'pie',
  data: {
    labels: ['Red', 'Blue', 'Yellow'],
    datasets: [{
      label: 'My First Dataset',
      data: [300, 50, 100],
      backgroundColor: ['#4B93CF', '#B6B8C3', '#D8D9DF'],
      borderWidth: 0
    }]
  }
});
new Chart(categoryProducts, {
  type: 'pie',
  data: {
    labels: ['Red', 'Blue', 'Yellow'],
    datasets: [{
      label: 'My First Dataset',
      data: [300, 50, 100],
      backgroundColor: ['#4B93CF', '#B6B8C3', '#D8D9DF'],
      borderWidth: 0
    }]
  }
});


// All Products
const product1Graph = document.getElementById('product1Graph');
const product1Pie = document.getElementById('product1Pie');
const product2Graph = document.getElementById('product2Graph');
const product2Pie = document.getElementById('product2Pie');
new Chart(product1Graph, {
  type: 'bar',
  data: {
    // labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [{
      label: ['# of Votes'],
      data: [12, 19, 3, 5, 2, 3, 12, 19, 3, 5, 2, 3],
      borderWidth: 1
    }]
  },
  options: {
    scales: {
      y: {
        beginAtZero: true
      }
    }
  }
});
new Chart(product1Pie, {
  type: 'pie',
  data: {
    labels: ['Red', 'Blue', 'Yellow'],
    datasets: [{
      label: 'My First Dataset',
      data: [300, 50, 100],
      backgroundColor: ['#4B93CF', '#B6B8C3', '#D8D9DF'],
      borderWidth: 0
    }]
  }
});

new Chart(product2Graph, {
  type: 'bar',
  data: {
    // labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [{
      label: ['# of Votes'],
      data: [12, 19, 3, 5, 2, 3, 12, 19, 3, 5, 2, 3],
      borderWidth: 1
    }]
  },
  options: {
    scales: {
      y: {
        beginAtZero: true
      }
    }
  }
});
new Chart(product2Pie, {
  type: 'pie',
  data: {
    labels: ['Red', 'Blue', 'Yellow'],
    datasets: [{
      label: 'My First Dataset',
      data: [300, 50, 100],
      backgroundColor: ['#4B93CF', '#B6B8C3', '#D8D9DF'],
      borderWidth: 0
    }]
  }
});